# Credits

## Creators
- [BloodyBoss](https://twitter.com/SparksTheGamer)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
