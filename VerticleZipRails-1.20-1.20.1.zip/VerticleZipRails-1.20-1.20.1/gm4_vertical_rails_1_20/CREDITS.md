# Credits

## Creators
- [BloodyBoss](https://twitter.com/SparksTheGamer)

## Updated by
- [SpecialBuilder32](https://twitter.com/SpecialBuilder)
- [Kruthers](https://twitter.com/Pandakruthers)

## Icon Design
- [DuckJr](https://twitter.com/DuckJr94)
